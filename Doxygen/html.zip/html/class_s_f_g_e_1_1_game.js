var class_s_f_g_e_1_1_game =
[
    [ "GetElapsed", "class_s_f_g_e_1_1_game.html#aba5b734c53a2f0a4e5b85dac6d8ef72c", null ],
    [ "Render", "class_s_f_g_e_1_1_game.html#aff3171926fe462355494bc708a2dccee", null ],
    [ "RestartClock", "class_s_f_g_e_1_1_game.html#a16fca19e7b497e8d7380933b1089abf3", null ],
    [ "Run", "class_s_f_g_e_1_1_game.html#a2321d777d35bdb1d58e91905f8c67424", null ],
    [ "Update", "class_s_f_g_e_1_1_game.html#a18aaeb90382b2ece889eb72d5d4a5ab1", null ],
    [ "m_clock", "class_s_f_g_e_1_1_game.html#ae611c4b56d168fb0bce20e25395827cf", null ],
    [ "m_elapsed", "class_s_f_g_e_1_1_game.html#ab3fe228837dba115df871c2f892d0307", null ]
];