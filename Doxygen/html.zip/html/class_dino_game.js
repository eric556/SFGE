var class_dino_game =
[
    [ "DinoGame", "class_dino_game.html#aa46025fc014bc6f674c34630d51a5f86", null ],
    [ "~DinoGame", "class_dino_game.html#a50547e09db5112fc223ac784fb10a91b", null ],
    [ "GetWindow", "class_dino_game.html#ab49eca7c35a8ddbab76afb252772b906", null ],
    [ "Render", "class_dino_game.html#a11d2686ca13270d9b1c6322de0e81958", null ],
    [ "Run", "class_dino_game.html#acb5e5f9b7bef66dfe74f0edcc9d52f16", null ],
    [ "Update", "class_dino_game.html#a6f46899d53324b223b0a40fc359b4e25", null ]
];