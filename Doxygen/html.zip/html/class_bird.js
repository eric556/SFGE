var class_bird =
[
    [ "Bird", "class_bird.html#a14dd98967cbe0ce689edc4d639de4ff2", null ],
    [ "Draw", "class_bird.html#a9a0e36dd29f7ca92099fb972e623357d", null ],
    [ "SetTexture", "class_bird.html#a5f8df89e894cbd8dc34ebd088b0c0c3e", null ],
    [ "Update", "class_bird.html#a99bf207f7b48ee38f737c28994cda20f", null ],
    [ "animClock", "class_bird.html#a262ca9bf99e8e61d8bc6a91fecdabe50", null ],
    [ "body", "class_bird.html#a48fb21d603e89c3f13db026e1895dab9", null ],
    [ "boundingBox", "class_bird.html#a31580fd1b4912c247c7ca670922618cc", null ],
    [ "currentFrame", "class_bird.html#ac1c4932bf06f8e140eb3dc04565d8d08", null ],
    [ "timeBetweenFrames", "class_bird.html#a208525eaa504d83a0c00b196ec0480b9", null ],
    [ "vel", "class_bird.html#aa101caa5984a17c3f6c639bcca94945f", null ]
];