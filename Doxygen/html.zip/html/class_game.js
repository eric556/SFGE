var class_game =
[
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "~Game", "class_game.html#ae3d112ca6e0e55150d2fdbc704474530", null ],
    [ "GetElapsed", "class_game.html#ade0a1547ad75abe90bf85394095a8d17", null ],
    [ "GetWindow", "class_game.html#a5f5aa47d5aa5e1bd05a39f1edd90b0d4", null ],
    [ "HandleInput", "class_game.html#a6cb82eaece4e30724f3fe4e0d4bde5fc", null ],
    [ "Render", "class_game.html#a0897730fc9fed789f6c0f11d21a0c14a", null ],
    [ "RestartClock", "class_game.html#ad4815ee928339191d9a317685f0320f9", null ],
    [ "Update", "class_game.html#a1c5373c68261c54aff03e6abe40fee52", null ]
];