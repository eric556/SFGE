var class_g_u_i =
[
    [ "GUI", "class_g_u_i.html#a449e298cc0f221fc8efe9e3cbee5b0f0", null ],
    [ "~GUI", "class_g_u_i.html#ac9cae2328dcb5d83bdfaeca49a2eb695", null ],
    [ "Render", "class_g_u_i.html#a44f2f24bc8911685db1c493ac4794e8d", null ],
    [ "Update", "class_g_u_i.html#a870594ffbb01c033370cd4a371e5fcc4", null ]
];