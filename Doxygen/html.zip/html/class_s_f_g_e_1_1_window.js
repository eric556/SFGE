var class_s_f_g_e_1_1_window =
[
    [ "Window", "class_s_f_g_e_1_1_window.html#ab3b95de2462905b5dd5318b2bf704801", null ],
    [ "Window", "class_s_f_g_e_1_1_window.html#a48ff8fe845ca7bcaec49287a90307132", null ],
    [ "~Window", "class_s_f_g_e_1_1_window.html#a245d821e6016fa1f6970ccbbedd635f6", null ],
    [ "BeginDraw", "class_s_f_g_e_1_1_window.html#a6c50108176dbb2ca3bac34d445a6aa12", null ],
    [ "Close", "class_s_f_g_e_1_1_window.html#a9f6bd65248aa0e3a0a14d63ef77bbda1", null ],
    [ "Draw", "class_s_f_g_e_1_1_window.html#a82a85026ba17153b33f0cfc5bb3778d6", null ],
    [ "Draw", "class_s_f_g_e_1_1_window.html#ac9139591aafe351c9cc69f7525a1adf5", null ],
    [ "EndDraw", "class_s_f_g_e_1_1_window.html#a8d4bf9571a74b652b001dcf6001704ec", null ],
    [ "GetClearColor", "class_s_f_g_e_1_1_window.html#a7f20cb56b6ab9d9b2a3c3581a668c279", null ],
    [ "GetEventManager", "class_s_f_g_e_1_1_window.html#aa348faa3bebb6ffb037946f32ea5ccdc", null ],
    [ "GetRenderWindow", "class_s_f_g_e_1_1_window.html#a550f2b7a8b18d173a823eb33b17b99a4", null ],
    [ "GetWindowSize", "class_s_f_g_e_1_1_window.html#aec19abd2d540c79560401e5d29831d63", null ],
    [ "IsDone", "class_s_f_g_e_1_1_window.html#aba7b260fabe834793c8801a572e0a3ab", null ],
    [ "IsFocused", "class_s_f_g_e_1_1_window.html#ab3f7c39a71ddab94b91eb24dc2e0e497", null ],
    [ "IsFullscreen", "class_s_f_g_e_1_1_window.html#a2dd1a6e2753665f038247304ead125da", null ],
    [ "SetClearColor", "class_s_f_g_e_1_1_window.html#a5f3529ddb90bdc650e5c50429c8bdd28", null ],
    [ "SetDone", "class_s_f_g_e_1_1_window.html#a16ec5f3a96f2d835de1bbaa9b4477199", null ],
    [ "ToggleFullscreen", "class_s_f_g_e_1_1_window.html#af5edfb4193f7e982e9026dde19170b60", null ],
    [ "Update", "class_s_f_g_e_1_1_window.html#ab8d28dce3166c70eb5744466460795df", null ]
];