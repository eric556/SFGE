var annotated_dup =
[
    [ "SFGE", null, [
      [ "Math", null, [
        [ "vector2", null, [
          [ "Vector2f", "class_s_f_g_e_1_1_math_1_1vector2_1_1_vector2f.html", "class_s_f_g_e_1_1_math_1_1vector2_1_1_vector2f" ]
        ] ]
      ] ],
      [ "Physics", null, [
        [ "Math", null, [
          [ "Vector2", "class_s_f_g_e_1_1_physics_1_1_math_1_1_vector2.html", "class_s_f_g_e_1_1_physics_1_1_math_1_1_vector2" ]
        ] ]
      ] ],
      [ "BaseState", "class_s_f_g_e_1_1_base_state.html", "class_s_f_g_e_1_1_base_state" ],
      [ "Binding", "struct_s_f_g_e_1_1_binding.html", "struct_s_f_g_e_1_1_binding" ],
      [ "EventDetails", "struct_s_f_g_e_1_1_event_details.html", "struct_s_f_g_e_1_1_event_details" ],
      [ "EventInfo", "struct_s_f_g_e_1_1_event_info.html", "struct_s_f_g_e_1_1_event_info" ],
      [ "EventManager", "class_s_f_g_e_1_1_event_manager.html", "class_s_f_g_e_1_1_event_manager" ],
      [ "Game", "class_s_f_g_e_1_1_game.html", "class_s_f_g_e_1_1_game" ],
      [ "SharedContext", "struct_s_f_g_e_1_1_shared_context.html", "struct_s_f_g_e_1_1_shared_context" ],
      [ "StateManager", "class_s_f_g_e_1_1_state_manager.html", "class_s_f_g_e_1_1_state_manager" ],
      [ "Window", "class_s_f_g_e_1_1_window.html", "class_s_f_g_e_1_1_window" ]
    ] ],
    [ "BasicGame", "class_basic_game.html", "class_basic_game" ],
    [ "Bird", "class_bird.html", "class_bird" ],
    [ "Cactus", "class_cactus.html", "class_cactus" ],
    [ "Dino", "class_dino.html", "class_dino" ],
    [ "DinoGame", "class_dino_game.html", "class_dino_game" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "GUI", "class_g_u_i.html", "class_g_u_i" ],
    [ "Instruction", "class_instruction.html", "class_instruction" ],
    [ "Leaderboard", "class_leaderboard.html", "class_leaderboard" ],
    [ "Menu", "class_menu.html", "class_menu" ],
    [ "Particle", "struct_particle.html", "struct_particle" ],
    [ "Pickup", "class_pickup.html", "class_pickup" ],
    [ "PongGame", "class_pong_game.html", "class_pong_game" ],
    [ "Snake", "class_snake.html", "class_snake" ],
    [ "SnakeSegment", "struct_snake_segment.html", "struct_snake_segment" ],
    [ "Window", "class_window.html", "class_window" ],
    [ "World", "class_world.html", "class_world" ]
];