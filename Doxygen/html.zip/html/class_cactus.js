var class_cactus =
[
    [ "Cactus", "class_cactus.html#a950335cab43609b772d6cbeea8f6ca58", null ],
    [ "Draw", "class_cactus.html#a1122a2140bc3b85e650f2b6ec8a06bda", null ],
    [ "SetTexture", "class_cactus.html#add57970bc7f1e991a06f4c05cd4fa9d6", null ],
    [ "body", "class_cactus.html#a8a180bfb00361e7f776a51feafc2f6dc", null ],
    [ "indexOfSpriteSheet", "class_cactus.html#a985a11748a56c0f61f7c0951051b84e1", null ]
];