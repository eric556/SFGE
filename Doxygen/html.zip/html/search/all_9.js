var searchData=
[
  ['normalize',['normalize',['../class_s_f_g_e_1_1_physics_1_1_math_1_1_vector2.html#ad1cd5ab0f6423dd0db629b14594e830b',1,'SFGE::Physics::Math::Vector2']]]
];
