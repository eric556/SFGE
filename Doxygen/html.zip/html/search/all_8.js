var searchData=
[
  ['magnitude',['magnitude',['../class_s_f_g_e_1_1_physics_1_1_math_1_1_vector2.html#a1260beeeab36bf36199ade2c5bdeb55b',1,'SFGE::Physics::Math::Vector2']]],
  ['magnitudesqrt',['magnitudeSqrt',['../class_s_f_g_e_1_1_physics_1_1_math_1_1_vector2.html#a2b8053f8677268ba045b7b5fabc1fe69',1,'SFGE::Physics::Math::Vector2']]],
  ['menu',['Menu',['../class_menu.html',1,'']]]
];
