var searchData=
[
  ['eventdetails',['EventDetails',['../struct_s_f_g_e_1_1_event_details.html',1,'SFGE']]],
  ['eventinfo',['EventInfo',['../struct_s_f_g_e_1_1_event_info.html',1,'SFGE']]],
  ['eventmanager',['EventManager',['../class_s_f_g_e_1_1_event_manager.html',1,'SFGE']]]
];
