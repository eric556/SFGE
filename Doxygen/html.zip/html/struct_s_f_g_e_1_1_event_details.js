var struct_s_f_g_e_1_1_event_details =
[
    [ "EventDetails", "struct_s_f_g_e_1_1_event_details.html#a3cbbd98c73e44f79e56d6834b4756a29", null ],
    [ "Clear", "struct_s_f_g_e_1_1_event_details.html#acf2058ebff90f1a57ba34b5af4b7d012", null ],
    [ "m_keyCode", "struct_s_f_g_e_1_1_event_details.html#ac265b63e5bcc9298f49f6d56390a5964", null ],
    [ "m_mouse", "struct_s_f_g_e_1_1_event_details.html#a95f2fe1ed80e914b2db7610b3a12184a", null ],
    [ "m_mouseWheelDelta", "struct_s_f_g_e_1_1_event_details.html#a47a24ecef3f101320f278af719c17389", null ],
    [ "m_name", "struct_s_f_g_e_1_1_event_details.html#a561f25fdd3e8b927d21619d116f6d1bd", null ],
    [ "m_size", "struct_s_f_g_e_1_1_event_details.html#a35c00051f111e11435724465c7d3ceca", null ],
    [ "m_textEntered", "struct_s_f_g_e_1_1_event_details.html#a05b0a3e67862c53268d5692611266657", null ]
];