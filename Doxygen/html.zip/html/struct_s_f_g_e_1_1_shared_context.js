var struct_s_f_g_e_1_1_shared_context =
[
    [ "SharedContext", "struct_s_f_g_e_1_1_shared_context.html#a6597d5bcf21b2a3eac5a6aa4ccb3f170", null ],
    [ "m_eventManager", "struct_s_f_g_e_1_1_shared_context.html#afb8d58faacdaf6f2f726f59a2ead4fed", null ],
    [ "m_wind", "struct_s_f_g_e_1_1_shared_context.html#a852fffc1e3c9f6ef221e51e4399c82e0", null ]
];