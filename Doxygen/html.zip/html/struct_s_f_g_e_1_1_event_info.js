var struct_s_f_g_e_1_1_event_info =
[
    [ "EventInfo", "struct_s_f_g_e_1_1_event_info.html#abcf39946120429632655fc649c0fc5eb", null ],
    [ "EventInfo", "struct_s_f_g_e_1_1_event_info.html#a6d3d8babe4a34fa835e40f5f65dc0b1e", null ],
    [ "m_code", "struct_s_f_g_e_1_1_event_info.html#abed7953f41e5a4ebecd947d9d9b8899a", null ]
];