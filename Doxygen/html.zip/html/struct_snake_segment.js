var struct_snake_segment =
[
    [ "SnakeSegment", "struct_snake_segment.html#ac967b63cb102d3f9fb1c9d77ca6a5d57", null ],
    [ "position", "struct_snake_segment.html#a466c2ed84944cad2084baba5d150e3f2", null ]
];