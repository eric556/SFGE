var class_dino =
[
    [ "Dino", "class_dino.html#a515ac3116e6ec3d5613ebb69b9794ce9", null ],
    [ "Draw", "class_dino.html#a2530ef238205e94d1dfbc14408444656", null ],
    [ "SetTexture", "class_dino.html#a3c0834b24460a61b3a442c27a3192623", null ],
    [ "Update", "class_dino.html#a14cea1c7181cdd74c0ed7d88d88b6430", null ],
    [ "animClock", "class_dino.html#ac9df894b8d916069af46f2fa55c031f3", null ],
    [ "animState", "class_dino.html#a67ba4ba0cf21b027181fa4b4cf82582f", null ],
    [ "body", "class_dino.html#af2d4eab96bef5950ac7fd641ecbd2bbf", null ],
    [ "currentFrame", "class_dino.html#a81f8ac50658714acb88891329b2b5855", null ],
    [ "dead", "class_dino.html#a6277dab8773f3a8ad01f4ef277a78837", null ],
    [ "deathClock", "class_dino.html#ac607d6c1166e985e185b24a44046f580", null ],
    [ "timeBetweenFrames", "class_dino.html#aa3a8625eeed797e6251bee7d76ecf70f", null ]
];