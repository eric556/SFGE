var class_window =
[
    [ "Window", "class_window.html#a74e6087da23d3c24e9fac0245e5ec92c", null ],
    [ "Window", "class_window.html#a4ff38eb9dc025b61146446eea65c46fc", null ],
    [ "~Window", "class_window.html#a245d821e6016fa1f6970ccbbedd635f6", null ],
    [ "BeginDraw", "class_window.html#a6c50108176dbb2ca3bac34d445a6aa12", null ],
    [ "Draw", "class_window.html#a82a85026ba17153b33f0cfc5bb3778d6", null ],
    [ "EndDraw", "class_window.html#a8d4bf9571a74b652b001dcf6001704ec", null ],
    [ "GetRenderWindow", "class_window.html#af7a29f723127223a43aabb7c56860844", null ],
    [ "GetWindowSize", "class_window.html#aec19abd2d540c79560401e5d29831d63", null ],
    [ "IsDone", "class_window.html#aba7b260fabe834793c8801a572e0a3ab", null ],
    [ "IsFullscreen", "class_window.html#a2dd1a6e2753665f038247304ead125da", null ],
    [ "SetDone", "class_window.html#a16ec5f3a96f2d835de1bbaa9b4477199", null ],
    [ "ToggleFullscreen", "class_window.html#af53b46d300ae7efc94d7264ee65315e3", null ],
    [ "Update", "class_window.html#ab8d28dce3166c70eb5744466460795df", null ]
];